# Renato Car Play — protótipo Android 0.1

Aplicativo inicial em português para central multimídia e tablets Android.

## Requisitos definidos
- Android mínimo: 6.0 (API 23)
- Teste inicial: Samsung Galaxy Tab S6 Lite SM-P619, Android 14
- Orientação: paisagem
- Interface: tela cheia
- Nome exibido: Renato Car Play

## O que já existe nesta versão
- Aplicativo Android nativo que abre uma interface WebView local
- Painel inicial em português
- Relógio e data
- Leitura de velocidade GPS, altitude e coordenadas quando o aparelho fornece localização e a permissão é concedida
- Temas de cores azul, vermelho, verde e dourado
- Atalhos básicos para Maps, Spotify e Ajustes (dependem dos aplicativos instalados)
- Arquivo HTML local, sem servidor obrigatório

## O que ainda NÃO está pronto
Esta é uma primeira base/protótipo, não um clone completo do CarWebGuru:
- O mapa central é apenas uma área visual, ainda não é navegação real
- Clima ainda não consulta uma fonte meteorológica
- O editor de arrastar/soltar ainda é muito básico e não persiste layouts
- A bússola ainda não lê sensores
- Ainda não há biblioteca com 10 temas completos
- Não há seleção dinâmica de todos os apps instalados
- Não está configurado como launcher padrão nem inicializa automaticamente
- É necessário testar GPS/permissões em aparelhos reais

## Como gerar o APK gratuitamente pelo GitHub Actions
1. Crie uma conta gratuita no GitHub, se ainda não tiver.
2. Crie um repositório novo chamado `renato-car-play`.
3. Envie o conteúdo desta pasta para o repositório (pode usar o site do GitHub pelo navegador).
4. Abra a aba **Actions** do repositório.
5. Escolha **Build Renato Car Play APK** e toque em **Run workflow**.
6. Quando terminar, abra a execução concluída e baixe o artefato **Renato-Car-Play-debug**.
7. Extraia o ZIP do artefato para obter `app-debug.apk` e instale no tablet, autorizando a instalação pelo navegador/gerenciador de arquivos se o Android solicitar.

O workflow usa GitHub Actions e ferramentas Android/Gradle gratuitas dentro dos limites da conta. O GitHub pode aplicar limites de uso; não é uma garantia de serviço ilimitado.

## Segurança
O APK debug é para teste, não é uma versão final assinada para distribuição pública. Não coloque senhas ou chaves privadas no repositório.
